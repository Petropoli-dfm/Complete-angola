import { Deposit, Withdrawal } from '../types';

// Estes arrays servem como estado inicial para a aplicação quando o localStorage está vazio.
// Os perfis de usuário são criados dinamicamente no App.tsx quando um usuário se autentica.
export const DUMMY_DEPOSITS: Deposit[] = [];
export const DUMMY_WITHDRAWALS: Withdrawal[] = [];