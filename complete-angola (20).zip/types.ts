// FIX: Removed self-import of `User` which was causing a declaration conflict.
export interface InvestmentLevel {
  nivel: number;
  compra: number;
  ganho: number;
  dias: number;
}

export interface ActiveInvestment extends InvestmentLevel {
  purchaseDate: number;
  lastCheckedDate: number;
}

export type Page = 'HOME' | 'INVEST' | 'TASKS' | 'REAL_GAME' | 'DEMO_GAME' | 'ACCOUNT' | 'LOGOUT' | 'SPIN_GAME';

export interface AppNotification {
    id: string;
    message: string;
    timestamp: number;
    read: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  balance: number;
  level?: number;
  activeInvestments: ActiveInvestment[];
  withdrawalHistory: Withdrawal[];
  hasDeposited: boolean;
  fcmToken?: string;
  gamesPlayed?: number;
  notifications: AppNotification[];
  isActive: boolean; // Adicionado para controlo de status do utilizador
  phoneNumber?: string;
  iban?: string;
  referrerId?: string | null;
  invitedUsersCount?: number;
  hasPurchasedLevelZero?: boolean;
  investmentsMigrated_v2?: boolean;
}

export interface QuizQuestion {
    question: string;
    correctAnswer: 'Verdade' | 'Falso';
}

export interface Withdrawal {
    id: string;
    userId: string;
    userName: string;
    amount: number;
    details: string;
    date: any; // Alterado para compatibilidade com Firestore Timestamp
    status: 'Pendente' | 'Aprovado' | 'Rejeitado';
}

export interface Deposit {
    id: string;
    userId: string;
    userName: string;
    amount: number;
    senderPhone: string;
    date: any; // Alterado para compatibilidade com Firestore Timestamp
    status: 'Pendente' | 'Aprovado' | 'Rejeitado';
    receiptHash?: string;
}

export interface ReactivationRequest {
    id: string;
    userId: string;
    userName: string;
    userEmail: string;
    date: any; // Firestore Timestamp
    status: 'Pendente' | 'Aprovado' | 'Rejeitado';
}

export interface ChatMessage {
    id: string;
    sender: 'user' | 'admin';
    text: string;
    timestamp: any; // Alterado para compatibilidade com Firestore Timestamp
}

// Objeto de utilizador simplificado para evitar erros de estrutura circular no estado do React
export interface SimpleFirebaseUser {
    uid: string;
    email: string | null;
    displayName: string | null;
}