import { useState, useCallback } from 'react';
import { ToastProps } from '../components/NotificationToast.tsx';

type ToastData = Omit<ToastProps, 'id' | 'onDismiss'>;

export const useNotifications = () => {
    const [toasts, setToasts] = useState<Omit<ToastProps, 'onDismiss'>[]>([]);

    const showNotification = useCallback((message: string) => {
        if (!message) return;
        const id = Date.now().toString() + Math.random();
        setToasts(prevToasts => [...prevToasts, { message, id }]);
    }, []);

    const dismissNotification = useCallback((id: string) => {
        setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    }, []);

    return { toasts, showNotification, dismissNotification };
};