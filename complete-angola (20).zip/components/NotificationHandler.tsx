import React, { useEffect, useState } from 'react';
import { requestForToken, onMessageListener } from '../services/firebase.ts';
import { User } from '../types.ts';

interface NotificationHandlerProps {
    user: User;
    showNotification: (message: string) => void;
}

const NotificationPermissionBanner: React.FC<{ onAllow: () => void; onDismiss: () => void; }> = ({ onAllow, onDismiss }) => (
     <div className="fixed bottom-24 left-4 right-4 md:left-auto bg-brand-light-gray p-3 text-white text-sm flex justify-between items-center animate-fade-in rounded-lg shadow-lg z-30 max-w-md">
        <p className="mr-4">Ative as notificações para receber atualizações importantes!</p>
        <div className="flex-shrink-0">
            <button onClick={onAllow} className="font-bold bg-brand-yellow text-brand-black px-3 py-1 rounded-md text-xs mr-2">Permitir</button>
            <button onClick={onDismiss} className="font-bold text-gray-400 text-xs">Agora não</button>
        </div>
    </div>
);


const NotificationHandler: React.FC<NotificationHandlerProps> = ({ user, showNotification }) => {
    const [showBanner, setShowBanner] = useState(false);

    useEffect(() => {
        // Mostra o banner apenas se a permissão ainda não foi solicitada.
        if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
             // Atraso para não sobrecarregar o usuário no carregamento da página
            const timer = setTimeout(() => setShowBanner(true), 3000);
            return () => clearTimeout(timer);
        }
    }, []);

    useEffect(() => {
        // Ouve por mensagens apenas quando o componente está montado
        const unsubscribe = onMessageListener()
            .then((payload: any) => {
                if (payload.notification?.body) {
                   showNotification(payload.notification.body);
                }
            })
            .catch((err) => console.log('Falha ao ouvir mensagens: ', err));

        // Retorna uma função de limpeza, embora onMessageListener não forneça uma
        return () => { /* lógica de limpeza se necessário */ };
    }, [showNotification]);

    const handleAllowNotifications = async () => {
        await requestForToken(); // This function now handles saving the token to Firestore
        setShowBanner(false);
    };

    if (!user || typeof Notification === 'undefined' || Notification.permission !== 'default' || !showBanner) {
        return null;
    }

    return <NotificationPermissionBanner onAllow={handleAllowNotifications} onDismiss={() => setShowBanner(false)} />;
};

export default NotificationHandler;