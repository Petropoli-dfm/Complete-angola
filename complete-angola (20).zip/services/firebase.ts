import { initializeApp } from 'firebase/app';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';
import { 
    getAuth, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signOut, 
    onAuthStateChanged,
    updateProfile,
    User as FirebaseUser
} from 'firebase/auth';
import { 
    getFirestore,
    collection,
    doc,
    setDoc,
    getDoc,
    getDocs,
    updateDoc,
    deleteDoc,
    onSnapshot,
    addDoc,
    query,
    where,
    orderBy,
    serverTimestamp,
    arrayUnion,
    writeBatch,
    increment,
} from 'firebase/firestore';


// Configuração do Firebase com as chaves corretas fornecidas.
const firebaseConfig = {
  apiKey: "AIzaSyBztAAGBIo7FpfGWtRXORd2CRgf6fzrHlc",
  authDomain: "complete-angola-25f65.firebaseapp.com",
  projectId: "complete-angola-25f65",
  storageBucket: "complete-angola-25f65.firebasestorage.app",
  messagingSenderId: "160253853169",
  appId: "1:160253853169:web:d1e3a83091006910409850"
};


const app = initializeApp(firebaseConfig);
const messaging = getMessaging(app);
export const auth = getAuth(app);
export const db = getFirestore(app);


export const requestForToken = async () => {
    try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
            console.log('Permissão para notificações concedida.');
            // Chave VAPID fornecida pelo usuário para autenticar as notificações push.
            const vapidKey = 'BJaVUkd7upJT1dWw5hgPTVFtXFM1TNQrtOf5eT56Ng6VvJeyD-ncdOltJzyVRmL_ZhMXG4eZYJGRGiKVd0slKeE';
            const currentToken = await getToken(messaging, { vapidKey });
            if (currentToken) {
                console.log('Token FCM:', currentToken);
                const user = auth.currentUser;
                if (user) {
                    const userDocRef = doc(db, "users", user.uid);
                    await updateDoc(userDocRef, { fcmToken: currentToken });
                }
                return currentToken;
            } else {
                console.log('Nenhum token de registro disponível. Peça permissão para gerar um.');
                return null;
            }
        } else {
            console.log('Não foi possível obter permissão para notificar.');
            return null;
        }
    } catch (err) {
        console.error('Ocorreu um erro ao recuperar o token. ', err);
        return null;
    }
};

export const onMessageListener = () =>
  new Promise((resolve) => {
    onMessage(messaging, (payload) => {
      resolve(payload);
    });
});

// Exporta as funções e tipos de autenticação para serem usados no App.tsx
export { 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signOut,
    onAuthStateChanged,
    updateProfile,
    type FirebaseUser,
    // Firestore exports
    collection,
    doc,
    setDoc,
    getDoc,
    getDocs,
    updateDoc,
    deleteDoc,
    onSnapshot,
    addDoc,
    query,
    where,
    orderBy,
    serverTimestamp,
    arrayUnion,
    writeBatch,
    increment,
};