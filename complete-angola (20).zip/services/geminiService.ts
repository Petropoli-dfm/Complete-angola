import { GoogleGenAI, Type } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface ReceiptData {
    amount: number;
    date: string; // YYYY-MM-DD
    time: string; // HH:MM:SS
    isForged: boolean;
}

/**
 * Analyzes a receipt image to extract transaction details and check for forgery.
 * @param base64Image The base64 encoded string of the receipt image.
 * @returns A promise that resolves to the extracted receipt data or null if analysis fails.
 */
export const analyzeReceipt = async (base64Image: string): Promise<ReceiptData | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: {
                parts: [
                    {
                        inlineData: {
                            mimeType: 'image/jpeg',
                            data: base64Image,
                        },
                    },
                    {
                        text: "Analise a imagem deste comprovativo de pagamento. Extraia o valor total da transferência, a data e a hora da transação. Além disso, avalie se a imagem parece ter sido falsificada ou editada digitalmente (por exemplo, desalinhamento de texto, fontes diferentes, pixels inconsistentes). Forneça a resposta em formato JSON estrito com os campos 'amount' (como um número), 'date' (no formato 'YYYY-MM-DD'), 'time' (no formato 'HH:MM:SS') e 'isForged' (um booleano, true se parecer falso, false caso contrário). Se algum campo não for encontrado, retorne null para esse campo."
                    }
                ]
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        amount: { type: Type.NUMBER, nullable: true },
                        date: { type: Type.STRING, nullable: true },
                        time: { type: Type.STRING, nullable: true },
                        isForged: { type: Type.BOOLEAN, nullable: true },
                    },
                },
            },
        });

        const jsonString = response.text.trim();
        const parsed = JSON.parse(jsonString) as Partial<ReceiptData>;

        if (parsed.amount != null && parsed.date && parsed.time && parsed.isForged != null) {
            return parsed as ReceiptData;
        }

        console.warn("Análise do Gemini incompleta:", parsed);
        return null;

    } catch (error) {
        console.error("Erro ao analisar o comprovativo com a API Gemini:", error);
        return null;
    }
};

/**
 * Generates a fun fact about Angola or the world using the Gemini API.
 * @returns A promise that resolves to the fun fact string or a default message on error.
 */
export const getAngolaFact = async (): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: "Gere uma curiosidade curta e interessante sobre a história, cultura ou geografia de Angola, ou um facto interessante sobre o mundo. A resposta deve ser uma única frase concisa e cativante, sem introduções como 'Claro, aqui está...' ou 'Sabia que...'. Apenas o facto."
        });
        return response.text;
    } catch (error) {
        console.error("Erro ao obter curiosidade da API Gemini:", error);
        // Fallback fact in case of API error
        return "A Grande Muralha da China não é visível do espaço a olho nu, um mito popular comum.";
    }
};
